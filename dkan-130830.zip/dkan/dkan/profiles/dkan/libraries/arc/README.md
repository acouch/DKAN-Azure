ARC2
====

ARC2 is a PHP 5.3 library for working with RDF.
It also provides a MySQL-based triplestore with SPARQL support.

Feature-wise, ARC2 is now in a stable state with no further feature additions planned. 
Issues are still being fixed and Pull Requests are welcome, though.